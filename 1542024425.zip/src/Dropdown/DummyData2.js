export const BarChartData={
    labels:[
        "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday", 
        "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
        
    ],
    datasets:[
        {
    
        data:[400,200,700,400,800,300,400,200,700,400,800,300,400,200],
        backgroundColor: 'rgb(33, 114, 229) ',
     
    }
  
    ],
};