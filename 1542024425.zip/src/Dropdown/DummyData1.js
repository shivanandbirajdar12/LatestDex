export const LineChartData={
    labels:[
        "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday", "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday"
        
    ],
    datasets:[
        {
        label: "V2",
        data:[400,200,700,400,800,300,400,200,700,400,800,300,400,200],
        hoverBackgroundColor: 'purple',
        backgroundColor: 'rgb(33, 114, 229) ',
     
    }
  
    ],
};