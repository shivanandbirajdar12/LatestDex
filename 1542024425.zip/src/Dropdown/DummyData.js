export const BarChartData={
    labels:[
        "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday", "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday", "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
        "Sunday", "Monday",
        "Tuesday",
        "Wensday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
        
    ],
    datasets:[
        {
        label: "V2",
        data:[400,200,700,400,800,300,400,200,700,400,800,300,400,200,700,400,800,300,400,200,700,200,700,400,800,300,400,200,700],
        hoverBackgroundColor: 'purple',
        backgroundColor: 'hotpink',
     
    }
  
    ],
};