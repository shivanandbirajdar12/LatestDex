const apiEndpoint = 'https://api.example.com/tokenData';

export default apiEndpoint;