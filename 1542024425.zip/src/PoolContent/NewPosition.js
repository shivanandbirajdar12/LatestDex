// import React from 'react'
// import phquestion from "../Assets/images2/ph_question.png";
// const NewPosition = () => {
//   return (
//     <div>
      
//           <div className="px-2">
//             <div className="_883856ad ">Your Position</div>
//             <div className=" _883856ad">
//               <div className="d-flex">
//                 <img src={phquestion} style={{ height: "24px", width: "24px" }} alt="" />
//                 <img src={phquestion} style={{ height: "24px", width: "24px" }} alt="" />
//                 <div>Token1/Token2</div>
//               </div>
//               <div>141400</div>
//             </div>
//             <div className=" _883856ad">
//               <div >Your pool share</div>
//               <div>100.00000%</div>
//             </div>
//             <div className=" _883856ad">
//               <div >Token1:</div>
//               <div>99999.9</div>
//             </div>
//             <div className=" _883856ad">
//               <div >Token2:</div>
//               <div>19999.9</div>
//             </div>
//           </div>
        
//     </div>
//   )
// }

// export default NewPosition