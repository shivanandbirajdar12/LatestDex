import React, { useState } from 'react'
import Explore from './Explore';
import Swap from './Swap';
import Pool from './Pool';
import Analytics from './Analytics';
import Context from '../Context/Context';

export default function Dropdownstate({children}) {

    const [selectedNetwork, setSelectedNetwork] = useState({ name: 'Ethereum', icon: './images/sprint.png' });
   
    
  return (
    <Context.Provider  value={{selectedNetwork,setSelectedNetwork,}}>
         {children}
    </Context.Provider>
  )
}
